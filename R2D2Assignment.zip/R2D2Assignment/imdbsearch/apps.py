from django.apps import AppConfig


class ImdbsearchConfig(AppConfig):
    name = 'imdbsearch'
