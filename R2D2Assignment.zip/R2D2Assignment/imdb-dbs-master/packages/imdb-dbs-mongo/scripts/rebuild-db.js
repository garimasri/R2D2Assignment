// For developer's convenience

require('./destroy-db');
require('./build-db');
